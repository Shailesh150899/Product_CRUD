﻿using System.IO;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InventoryManagement.Controllers
{
    public class ProductsController : Controller
    {
        private readonly InventoryContext _context;

        public ProductsController(InventoryContext context)
        {
            _context = context;
        }

        // GET: Products
        public async Task<IActionResult> Index()
        {
            var products = await _context.Products.ToListAsync();

            return View(products);
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FirstOrDefaultAsync(m => m.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        public IActionResult Create()
        {
            return View();
        }


        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("ProductId,Name,Category,Color,UnitPrice,AvailableQuantity")] Products products)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(products);
        //        await _context.SaveChangesAsync();

        //        return RedirectToAction(nameof(Index));
        //    }

        //    return View(products);
        //}


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId,Name,Category,ProductFreshness,MRP,UnitPrice,ProductImage")] Products products, IFormFile productImage)
        {
            int productCount = await _context.Products.CountAsync();

            // Check if the product count has reached the limit (10 products)
            if (productCount >= 10)
            {
                ModelState.AddModelError("", "Cannot add more than 10 products.");
                return View(products);  // Return the view with the error
            }

            if (ModelState.IsValid)
            {


                if (products.MRP.HasValue && products.UnitPrice >= products.MRP.Value)
                {
                    ModelState.AddModelError("UnitPrice", "Unit Price must be less than MRP.");
                    return View(products);  // Return view with error
                }
                // Check if an image was uploaded
                if (productImage != null && productImage.Length > 0)
                {
                    // Generate a unique file name
                    var fileName = Path.GetFileName(productImage.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", fileName);

                    // Save the file to the server
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await productImage.CopyToAsync(stream);
                    }

                    // Save the file name to the ProductImage property of the product
                    products.ProductImage = fileName;
                }

                _context.Add(products);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(products);
        }





        // GET: Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }


        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(int id, [Bind("ProductId,Name,Category,Color,UnitPrice,AvailableQuantity")] Products updatedProductDetails)
        //{
        //    if (id != updatedProductDetails.ProductId)
        //    {
        //        return NotFound();
        //    }

        //    var product = await _context.Products.FindAsync(id);

        //    if (product == null)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            product.Name = updatedProductDetails.Name;
        //            product.Category = updatedProductDetails.Category;
        //            product.Color = updatedProductDetails.Color;
        //            product.UnitPrice = updatedProductDetails.UnitPrice;
        //            product.AvailableQuantity = updatedProductDetails.AvailableQuantity;

        //            _context.Update(product);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!ProductsExists(updatedProductDetails.ProductId))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }

        //        return RedirectToAction(nameof(Index));
        //    }

        //    return View(updatedProductDetails);
        //}










        // GET: Products/Delete/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductId,Name,Category,ProductFreshness,MRP,UnitPrice,ProductImage")] Products updatedProduct, IFormFile newProductImage)
        {
            if (id != updatedProduct.ProductId)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {

                    if (updatedProduct.MRP.HasValue && updatedProduct.UnitPrice >= updatedProduct.MRP.Value)
                    {
                        ModelState.AddModelError("UnitPrice", "Unit Price must be less than MRP.");
                        return View(updatedProduct);  // Return the view with the error
                    }

                    product.Name = updatedProduct.Name;
                    product.Category = updatedProduct.Category;
                    product.ProductFreshness = updatedProduct.ProductFreshness;
                    //product.Color = updatedProduct.Color;
                    product.UnitPrice = updatedProduct.UnitPrice;
                   // product.AvailableQuantity = updatedProduct.AvailableQuantity;
                    product.MRP = updatedProduct.MRP;

                    // If a new image is uploaded, save it and update the product's image file name
                    if (newProductImage != null && newProductImage.Length > 0)
                    {
                        // Delete the old image from the server (if it exists)
                        var oldImagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", product.ProductImage);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }

                        // Generate a new unique file name for the uploaded image
                        var newFileName = Path.GetFileName(newProductImage.FileName);
                        var newFilePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", newFileName);

                        // Save the new image to the server
                        using (var stream = new FileStream(newFilePath, FileMode.Create))
                        {
                            await newProductImage.CopyToAsync(stream);
                        }

                        // Update the product's ProductImage with the new image file name
                        product.ProductImage = newFileName;
                    }

                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductsExists(updatedProduct.ProductId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(updatedProduct);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var products = await _context.Products.FirstOrDefaultAsync(m => m.ProductId == id);

            if (products == null)
            {
                return NotFound();
            }

            return View(products);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        private bool ProductsExists(long id)
        {
            return _context.Products.Any(e => e.ProductId == id);
        }
    }
}
