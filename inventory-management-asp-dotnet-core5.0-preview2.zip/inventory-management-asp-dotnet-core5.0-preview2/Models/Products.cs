﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace InventoryManagement.Models
{
    public partial class Products
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
       // public string Color { get; set; }
        public decimal? MRP {  get; set; }    
        public decimal UnitPrice { get; set; }
       public string ProductFreshness {  get; set; }   
       // public int AvailableQuantity { get; set; }
        public string ProductImage { get; set; }
        public DateTime CreatedDate { get; set; }
    }




    
//    CREATE TABLE[dbo].[Products]
//    (
    
//        [ProductId][int] IDENTITY(1,1) NOT NULL,
    
//        [Name] [varchar] (50) NOT NULL,
    
//        [Category] [varchar] (30) NULL,
//	[ProductFreshness][nvarchar] (50) NULL,
//	[MRP][decimal] (18, 0) NULL,
//	[UnitPrice][decimal] (18, 0) NOT NULL,

//    [ProductImage] [nvarchar] (50) NULL,
//	[CreatedDate]
//    [datetime]
//    NOT NULL,
// CONSTRAINT[PK__Products__B40CC6CDA5E88BF4] PRIMARY KEY CLUSTERED
//(
//    [ProductId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO

//ALTER TABLE[dbo].[Products] ADD CONSTRAINT[DF__Products__Create__4B7B5F7C]  DEFAULT(getdate()) FOR[CreatedDate]
//GO

}
